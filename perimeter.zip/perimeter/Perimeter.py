try:
    def circle(_radius):
        '''
            circle(....)
            circle(self,  _radius)
             -> This returns the perimeter of circle  (circumference)
             -> accepts one argument: value of radius
        '''
        return 2*3.14*_radius
    def parallelogram(_base, _height):
        '''
            parallelogram(....)
            parallelogram(_base,_height)
             -> This returns the perimeter of parallelogram
             -> accepts the two arguments:value of base and value of height
        '''
        return 2 * (_base + _height)

    def triangle(*args):
        '''
            triangle(....)
            triangle(*args)
             -> This returns the perimeter of traingle
             -> accepts minimum 1 argument:value of one side if traingle is equilateral,2 arguments for isosceles and 3 for scalane traingle.
        '''
        c=0
        for i in args:
            c+=1
        if c==1:
            return (3*args)
        elif c==2:
            re=c
            for each in args:
                re=re*each
            return re
        elif c==3:
            re=0
            for each in args:
                re=re+each
            return re
        else:
            return "The sides you've enter for perimeter are not of triangle"

    def rectangle(_length, _width):
        '''
            rectangle(....)
            rectangle(,_length,_width)
             -> This returns the perimeter of rectangle
             -> accepts the two arguments:values of length and width/breadth
        '''
        return 2 * (_length + _width)

    def square(_side):
        '''
            square(....)
            square(_side)
             -> This returns the perimeter of square
             -> accepts an argument: value of side
        '''
        return 4 * _side

    def trapezoid(_a, _b, _c, _d):
        '''
            trapezoid(....)
            trapezoid(_a,_b,_c,_d):
             -> This returns the perimeter of trapezoid
             -> accepts the four arguments:values of its four sides
        '''
        return _a + _b + _c + _d

    def kite(_a, _b):
        '''
            kite(....)
            kite(self,_a,_b):
             -> This returns the perimeter of kite
             -> accepts the two arguments:values of four sides
        '''
        return 2 * (_a + _b)

    def rhombus(_a):
        '''
            rhombus(....)
            rhombus(self,_a):
             -> This returns the perimeter of rhombus
             -> accepts an argument:value of a side
        '''
        return 4 * _a

    def reg_polygon(_n,_l):
        '''
            reg_polygon(....)
            reg_polygon(self, _n, _l):
             -> This returns the perimeter of regular polygon (polygon with equal sides)
             -> accepts no. of sides _n and length _l
        '''
        return _n*_l
    def irreg_polygon(*args):
        '''
            irreg_polygon(....)
            irreg_polygon(self,*args);
             -> This returns the perimeter of irregular polygon (polygon with unequal sides)
             -> accepts lengths of  sides. minimum 4 sides can be accepted
        '''
        _c=0
        for each in args:
            _c+=1
        if _c<4:
            print("Function polygon() takes minimum 4 arguments")
            exit()
        else:
            _n = _c
            for i  in args:
                _n = _n * i
        return _n
except Exception as e:
    print(e)


